package App;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.Window;

public class Register extends Application {
	
	public Stage primaryStage;
	
	Scene scene;

	BorderPane borderPaneRegister = new BorderPane();
	
	GridPane gridPaneRegister = new GridPane();
	
	TextField nameRegisterInput = new TextField();
	
	TextField emailRegisterInput = new TextField();
	
	PasswordField passwordRegisterInput = new PasswordField();
	
	PasswordField confPasswordRegisterInput = new PasswordField();
	
	RadioButton male = new RadioButton("Male");
	RadioButton female = new RadioButton("Female");
	FlowPane flowPaneGender = new FlowPane();
	
	TextField phoneNumberRegisterInput = new TextField();
	
	TextArea addressRegisterInput = new TextArea();

	Button registerButton = new Button("Register");
	
	Hyperlink loginHyperlink = new Hyperlink("Already have account? Login here");
	
	ArrayList<User> UserData;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	public void fetchUserData() {
		Connect connect = Connect.getInstance();
		String query = "SELECT * FROM user";
		ResultSet rs = connect.execQuery(query);
		
		UserData = new ArrayList<>();
				
		try {
			while(rs.next()) {
				Integer id = rs.getInt("id");
				String username = rs.getString("username");
				String password = rs.getString("password");
				String email = rs.getString("email");
				String phone_number = rs.getString("phone_number");
				String address = rs.getString("address");
				String gender = rs.getString("gender");
				String role = rs.getString("role");
				
				User user = new User(id, username, password, email, phone_number, address, gender, role);
				UserData.add(user);
				
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}

	public void initializeRegister() {
		
		//arraylist to fetch userdata
		UserData = new ArrayList<>();
		primaryStage = new Stage();
		
		//layout
		scene = new Scene(borderPaneRegister, 900, 700 );
		borderPaneRegister.setBackground(new Background(new BackgroundFill(Color.KHAKI, CornerRadii.EMPTY, Insets.EMPTY)));
		
		borderPaneRegister.setCenter(gridPaneRegister);
		borderPaneRegister.setMargin(gridPaneRegister, new Insets(20));
		
		gridPaneRegister.setHgap(20);
		gridPaneRegister.setVgap(20);
		gridPaneRegister.setAlignment(Pos.CENTER);
		
		
		//register title
		Text registerTitle = new Text("REGISTER");
		registerTitle.setFont(new Font("Arial", 30));
		registerTitle.setStyle("-fx-font-weight: bold");
		
		borderPaneRegister.setTop(registerTitle);
		borderPaneRegister.setAlignment(registerTitle, Pos.CENTER);
		borderPaneRegister.setMargin(registerTitle, new Insets(20));
		
		
		//name register input		
		Text nameRegister = new Text("Name");
		nameRegister.setFont(new Font("Arial", 18));
		
		gridPaneRegister.add(nameRegister, 0, 0);
		gridPaneRegister.add(nameRegisterInput, 1, 0);

		
		//email register input		
		Text emailRegister = new Text("Email");
		emailRegister.setFont(new Font("Arial", 18));
		
		gridPaneRegister.add(emailRegister, 0, 1);
		gridPaneRegister.add(emailRegisterInput, 1, 1);
		
		
		//password register input		
		Text passwordRegister = new Text("Password");
		passwordRegister.setFont(new Font("Arial", 18));
		
		gridPaneRegister.add(passwordRegister, 0, 2);
		gridPaneRegister.add(passwordRegisterInput, 1, 2);
		
		
    	//confirm password register input		
		Text confPasswordRegister = new Text("Confirm Password");
		confPasswordRegister.setFont(new Font("Arial", 18));
		
		gridPaneRegister.add(confPasswordRegister, 0, 3);
		gridPaneRegister.add(confPasswordRegisterInput, 1, 3);
		
		
		//gender register input
		Text genderRegister = new Text("Gender");
		genderRegister.setFont(new Font("Arial", 18));
		
		gridPaneRegister.add(genderRegister, 0, 4);
		
		flowPaneGender.getChildren().addAll(male, female);
		
		flowPaneGender.setHgap(100);
		
		gridPaneRegister.add(flowPaneGender, 1, 4);
		
		ToggleGroup tg = new ToggleGroup();
		male.setToggleGroup(tg);
		female.setToggleGroup(tg);
		
		
		//phone number register input		
		Text phoneNumberRegister = new Text("Phone Number");
		phoneNumberRegister.setFont(new Font("Arial", 18));
		
		gridPaneRegister.add(phoneNumberRegister, 0, 5);
		gridPaneRegister.add(phoneNumberRegisterInput, 1, 5);
		
		
		//address register input		
		Text addressRegister = new Text("Address");
		addressRegister.setFont(new Font("Arial", 18));
		
		gridPaneRegister.add(addressRegister, 0, 6);	
		gridPaneRegister.add(addressRegisterInput, 1, 6);		
		
		//register button
		registerButton.setStyle("-fx-background-color: CRIMSON; -fx-text-fill: WHITE ");
		
		gridPaneRegister.add(registerButton, 1, 8);
		
		gridPaneRegister.setHalignment(registerButton, HPos.CENTER);
		
		registerButton.setOnAction((e)-> {
			
			String name = nameRegisterInput.getText();
			
			String email = emailRegisterInput.getText();
					
			String password = passwordRegisterInput.getText();
					
			String confPassword = confPasswordRegisterInput.getText();
					
			String gender;
			
			if (male.isSelected()) {
				gender = "Male";
			} else {
				gender = "Female";
			}
					
			String phone_number = phoneNumberRegisterInput.getText();
					
			String address = addressRegisterInput.getText();
					
			String role = "User";
					
			if (!name.isEmpty() && name.length() > 5 && name.length() < 20) {
//			contoh: Cindy
				
				if (!password.isEmpty() && password.length() > 5 && password.length() < 20) {			
					
					if (password.matches(".*[A-Za-z].*") && password.matches(".*[0-9].*") && password.matches("[A-Za-z0-9]*")) {
//					contoh: cindy123
						
						if (password.matches(confPassword)) {									
							
							if (email.matches("^(.+)@(\\S+)$")) {
//							contoh: cindyfayola@gmail.com										
								
								if (emailIsUnique(email)) {
											
									if (phone_number.matches("[0-9]+")) {
//									contoh: 0812												
											
											if (male.isSelected() || female.isSelected()) {
												
													new Login().openLogin(new Stage());
													primaryStage.close();
															
												} else {

												showAlert(Alert.AlertType.ERROR, gridPaneRegister.getScene().getWindow(), "Error", "Gender must be selected, either Male or Female.");
										              return;
														
											}
												
									} else {

										showAlert(Alert.AlertType.ERROR, gridPaneRegister.getScene().getWindow(), "Error", "Phone number must be numeric.");
								              return;
												
									}
											
								} else {

								showAlert(Alert.AlertType.ERROR, gridPaneRegister.getScene().getWindow(), "Error", "Email must unique");
						              return;
											
								}
										
							} else {

								showAlert(Alert.AlertType.ERROR, gridPaneRegister.getScene().getWindow(), "Error", "Email must in email format (ex. name@domain.com)");
						              return;
										
							}
									
						} else {
									
							showAlert(Alert.AlertType.ERROR, gridPaneRegister.getScene().getWindow(), "Error", "Confirm Password must be same with Password.");
					              return;
									
						}
								
					} else {
								
						showAlert(Alert.AlertType.ERROR, gridPaneRegister.getScene().getWindow(), "Error", "Password must be alphanumeric.");	
				              return;

					}
							
				} else {

					showAlert(Alert.AlertType.ERROR, gridPaneRegister.getScene().getWindow(), "Error", "Password must be between 5 - 20 characters");
			              return;
							
				}
						
			} else {

				showAlert(Alert.AlertType.ERROR, gridPaneRegister.getScene().getWindow(), "Error", "Username must be between 5 - 20 characters.");
		              return;
						
			}	
			
			});
		
	
		//hyperlink login		
		borderPaneRegister.setBottom(loginHyperlink);
		borderPaneRegister.setAlignment(loginHyperlink, Pos.CENTER);
		borderPaneRegister.setMargin(loginHyperlink, new Insets(20));
		
		loginHyperlink.setOnAction( e -> {
			new Login().openLogin(new Stage());
			primaryStage.close();
		});
		
	}
	
	public void openRegister(Stage stage) {
		stage.setScene(showRegister());
		stage.show();
		this.primaryStage = stage;
	}


	public Scene showRegister() {
		
		initializeRegister();
		fetchUserData();
		
		return scene;
		
	}
	
	private boolean emailIsUnique(String email) {
		
		Connect connect = Connect.getInstance();
		String queryUser = String.format("SELECT * FROM user where email = '%s'", email);
		connect.rs = connect.execQuery(queryUser);
		
		try {
			
			
			if (connect.rs.next() && connect.rs.getString("email") != null) {
				
				return false;
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return true;
	}
	
	private void showAlert(Alert.AlertType alertType, Window winMessage, String title, String message) {
		
        Alert alert = new Alert(alertType);
        
        alert.setTitle(title);
        
        alert.setHeaderText(null);
        
        alert.setContentText(message);
        
        alert.initOwner(winMessage);
        
        alert.show();
        
    }
	
	private void addDataUser(String name, String password, String email, String phone_number, String address, String gender, String role) {
		
		Connect connect = Connect.getInstance();
		String queryUser = "INSERT INTO user " + "VALUES ('0','"+name+"', '"+password+"','"+email+"','"+phone_number+"','"+address+"','"+gender+"','"+role+"')";
		connect.execUpdate(queryUser);
		
	}
	
	@Override
	public void start(Stage stage) throws Exception {
		// TODO Auto-generated method stub
		
		fetchUserData();
		initializeRegister();
		
		stage.setTitle("Kemanggisan Fried Chicken");
		stage.setScene(scene);
		stage.show();
		
		primaryStage = stage;
	}

}
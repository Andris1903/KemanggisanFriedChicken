package App;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Spinner;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TableView.TableViewSelectionModel;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
//import jfxtras.labs.scene.control.window.Window;
import jfxtras.labs.scene.control.window.Window;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import App.Cart;

public class BuyFood extends Application{
	
	private static Stage primaryStage;
	
	Scene scene;
	
	Window window;
	
	BorderPane borderPaneBuyFood = new BorderPane();
	
	GridPane gridPaneBuyFood = new GridPane();

	FlowPane flowPaneBuyFood = new FlowPane();
	
	private Food foodSelected;
	private Cart cartSelected;
	
	MenuBar menuBar = new MenuBar();
	Menu menu1 = new Menu("Menu");
	Menu menu2 = new Menu("Account");
	
	MenuItem menuItemUser1 = new MenuItem("Buy Food");
//	MenuItem menuItemUser2 = new MenuItem("Manage Food");
	MenuItem menuItemUser3 = new MenuItem("Transactions");
	MenuItem menuItemUser4 = new MenuItem("Log out");
	
	Spinner<Integer> quantitySpinner;
	
	Button addToCartButton = new Button ("Add to cart");
	Button removeFromCartButton = new Button ("Remove from cart");
	Button checkoutButton = new Button ("Checkout");
	
	TableView<Food> foodTable = new TableView<>();
	TableView<Cart> cartTable = new TableView<>();
	
	ArrayList<Food> FoodData;
	ArrayList<Cart> CartData;
	
	static ObservableList<Food> foodData;
	static ObservableList<Cart> cartData;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	public void fetchFoodData() {
		Connect connect = Connect.getInstance();
		String query = "SELECT * FROM food";
		ResultSet rs = connect.execQuery(query);
				
		try {
			while(rs.next()) {
				Integer id = rs.getInt("id");
				String name = rs.getString("name");
				String type = rs.getString("type");
				Integer price = rs.getInt("price");
				Integer stock = rs.getInt("stock");
				
				Food food = new Food(id, name, type, price, stock);
				FoodData.add(food);
				
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void openBuyFood(Stage stage) {
		stage.setScene(showBuyFood());
		stage.show();
		this.primaryStage = stage;
	}
	public void initializeBuyFood() {
	menuItemUser1.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				new BuyFood().openBuyFood(new Stage());
				primaryStage.close();
			}
		});
//	menuItemUser2.setOnAction(new EventHandler<ActionEvent>() {
//				
//				@Override
//				public void handle(ActionEvent event) {
//					// TODO Auto-generated method stub
//					new ManageFood().openManageFood(new Stage());
//					primaryStage.close();
//				}
//			});
	menuItemUser3.setOnAction(new EventHandler<ActionEvent>() {
		
		@Override
		public void handle(ActionEvent event) {
			// TODO Auto-generated method stub
			new Transaction().openTransaction(new Stage());;
			primaryStage.close();
		}
	});
	
		//arraylist to fetch food data and cart data
		FoodData = new ArrayList<>();
		CartData = new ArrayList<>();
		
		foodData = FXCollections.observableArrayList(FoodData);
		cartData = FXCollections.observableArrayList(CartData);
		
		cartTable.setItems(cartData);
		
		addToCartButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				
				
				if(quantitySpinner.getValue() > foodSelected.getStock()) {
					
					//Tampilin kekurangan stock
					alertMsg("Not enough stock");
					return;
				}
				for(int i = 0; i < cartData.size(); i++) {
					if(cartData.get(i).getFoodid() == foodSelected.getId()) {
						if(cartData.get(i).getQuantity() + quantitySpinner.getValue() > foodSelected.getStock()) {
							
							//Tampilin error kekurangan stock
							alertMsg("Not enough stock");
							
//							cartTable.setItems(cartData);
							return;
						} else {
							
							cartData.get(i).setQuantity(cartData.get(i).getQuantity() + quantitySpinner.getValue());
							cartData.get(i).setTotalprice(cartData.get(i).getQuantity() * foodSelected.getPrice());
							cartTable.refresh();
							return;
						}
					}
				}
				
				// TODO Auto-generated method stub
				System.out.println(cartData);
				cartData.add(new Cart(foodSelected.getId(), 
						foodSelected.getName(),
						foodSelected.getPrice(),
						quantitySpinner.getValue(),
						foodSelected.getPrice() * 
						quantitySpinner.getValue()));
				
				cartTable.setItems(cartData);
			}
			
		});
		
		removeFromCartButton.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				cartData.remove(cartSelected);
			}
			
		});
		
		checkoutButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				if(cartData.isEmpty()) {
					alertMsg("Cart is empty");
					return;
				}
					
					try {
						PreparedStatement set = Connect.getInstance().preparedStatement("INSERT INTO transaction_header (user_id) VALUES ('" + Login.user.getId() + "')"); // nanti ganti
						ResultSet key = set.getGeneratedKeys();
						key.next();
						int returnID = key.getInt(1);
							
						for(int i = 0; i < cartData.size(); i++) {
							
							System.out.println(returnID);
							Cart temp = cartData.get(i);
							Connect.getInstance().preparedStatement("INSERT INTO transaction_detail VALUES('"+returnID+"','"+temp.getFoodid()+"','"+temp.getQuantity()+"','"+ temp.getTotalprice() +"')");
						
						}
						
						cartData.removeAll(cartData);
					} catch (SQLException ex) {
						
						System.out.println(ex.getMessage());
					
					}
				}
			});
		
		//layout
		scene = new Scene(borderPaneBuyFood, 950, 580);
		
		gridPaneBuyFood.setVgap(20);
		gridPaneBuyFood.setHgap(40);
		gridPaneBuyFood.setPadding(new Insets(10));
		gridPaneBuyFood.setStyle("-fx-font-size: 16px");
		
		HBox b = new HBox();
		b.getChildren().addAll(gridPaneBuyFood, cartTable);
		flowPaneBuyFood.getChildren().addAll(foodTable, b);
		flowPaneBuyFood.setVgap(10);
		flowPaneBuyFood.setHgap(25);
		
		foodTable.setMaxSize(1000, 200);
		
		cartTable.setMaxSize(800, 300);
		
		cartTable.setStyle("-fx-font-size: 14px");
		
		//window
		window = new Window("Buy Food");
		window.setMaxSize(810, 580);
		
		borderPaneBuyFood.setCenter(window);
		
		window.getContentPane().getChildren().add(flowPaneBuyFood);
		
		
		//menu bar
		
		borderPaneBuyFood.setTop(menuBar);
		
		menuBar.getMenus().addAll(menu1, menu2);
		
		if(Login.user.getRole().equalsIgnoreCase("administrator") ) {
			
			menu1.getItems().addAll(menuItemUser3);		
			
		} else {
			
			menu1.getItems().addAll(menuItemUser1, menuItemUser3);
			
		}
		
		
		menu2.getItems().addAll(menuItemUser4);
		
		menuItemUser4.setOnAction( e -> {
			
			new Login().openLogin(new Stage());
			this.primaryStage.close();
			
		});
		
		
		//food id cart
		Text idCartInput = new Text("ID");
		
		gridPaneBuyFood.add(idCartInput, 0, 0);
		
		
		//food name cart
		Text nameCartInput = new Text("Name");
		
		gridPaneBuyFood.add(nameCartInput, 0, 1);
		
		
		//food type cart
		Text typeCartInput = new Text("Type");
		
		gridPaneBuyFood.add(typeCartInput, 0, 2);
		
		
		//food price cart
		Text priceCartInput = new Text("Price");
		
		gridPaneBuyFood.add(priceCartInput, 0, 3);
		
		
		//food stock cart
		Text stockCartInput = new Text("Stock");
		
		gridPaneBuyFood.add(stockCartInput, 0, 4);
		
		
		//food quantity cart
		Text quantityCartInput = new Text("Quantity:");
		
		gridPaneBuyFood.add(quantityCartInput, 3, 0);
		
		quantitySpinner = new Spinner<>(1, 100, 0, 1);
		
		gridPaneBuyFood.add(quantitySpinner, 3, 1);
		
		
		//add to cart button
		addToCartButton.setPrefWidth(150);
		
		gridPaneBuyFood.add(addToCartButton, 3, 2);
		
		
		//remove button
		gridPaneBuyFood.add(removeFromCartButton, 3, 3);
		
		
		//checkout button
		addToCartButton.setPrefWidth(150);
		
		gridPaneBuyFood.add(checkoutButton, 3, 4);
		
	}
	
	public static void switchScenes(Scene scene) {
		primaryStage.setScene(scene);
	}
	
	public void setTable() {
		
		//food table
		TableColumn<Food, Integer> idCol = new TableColumn<>("ID");
		idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
		idCol.setMinWidth(80);
		
		TableColumn<Food, String> nameCol = new TableColumn<>("Name");
		nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
		nameCol.setMinWidth(borderPaneBuyFood.getWidth()/4.2);
		
		TableColumn<Food, String> typeCol = new TableColumn<>("Type");
		typeCol.setCellValueFactory(new PropertyValueFactory<>("type"));
		typeCol.setMinWidth(borderPaneBuyFood.getWidth()/4.2);
		
		TableColumn<Food, Integer> priceCol = new TableColumn<>("Price");
		priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
		priceCol.setMinWidth(borderPaneBuyFood.getWidth()/4.2);
		
		TableColumn<Food, Integer> stockCol = new TableColumn<>("Stock");;
		stockCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
		stockCol.setMinWidth(borderPaneBuyFood.getWidth()/4.2);
				
		foodTable.getColumns().addAll(idCol, nameCol, typeCol, priceCol, stockCol);
		
		
		//cart table
		TableColumn<Cart, Integer> foodIDCol = new TableColumn<>("Food ID");
		foodIDCol.setCellValueFactory(new PropertyValueFactory<>("foodid"));
		
		TableColumn<Cart, String> foodNameCol = new TableColumn<>("Food Name");
		foodNameCol.setCellValueFactory(new PropertyValueFactory<>("foodname"));
		
		TableColumn<Cart, Integer> foodPriceCol = new TableColumn<>("Food Price");
		foodPriceCol.setCellValueFactory(new PropertyValueFactory<>("foodprice"));
		
		TableColumn<Cart, Integer> quantityCol = new TableColumn<>("Quantity");
		quantityCol.setCellValueFactory(new PropertyValueFactory<>("quantity"));
		
		TableColumn<Cart, Integer> totalPriceCol = new TableColumn<>("Total Price");
		totalPriceCol.setCellValueFactory(new PropertyValueFactory<>("totalprice"));
		
		cartTable.getColumns().addAll(foodIDCol, foodNameCol, foodPriceCol, quantityCol, totalPriceCol);
		
//		foodTable.getSelectionModel().selectedItemProperty().addListener((observableValue, oldValue, newValue) -> {
//            if (newValue != null) {
//            	TableViewSelectionModel selectionModel = foodTable.getSelectionModel();
//                ObservableList selectedCells = selectionModel.getSelectedCells();
//                TablePosition tablePosition = (TablePosition) selectedCells.get(0);
//                Object val = tablePosition.getTableColumn().getCellData(newValue);
//            }
//        });
		
		foodTable.setOnMouseClicked(new EventHandler<Event>() {
			
			public void handle(Event event) {
				
				foodSelected = foodTable.getSelectionModel().getSelectedItem();
				gridPaneBuyFood.getChildren().removeIf( node -> GridPane.getColumnIndex(node) == 1);
				gridPaneBuyFood.add(new Text(String.valueOf(foodSelected.getId())), 1, 0);
				gridPaneBuyFood.add(new Text(foodSelected.getName()), 1, 1);
				gridPaneBuyFood.add(new Text(foodSelected.getType()), 1, 2);
				gridPaneBuyFood.add(new Text(String.valueOf(foodSelected.getPrice())), 1, 3);
				gridPaneBuyFood.add(new Text(String.valueOf(foodSelected.getStock())), 1, 4);
				
			};
		});
		
		cartTable.setOnMouseClicked(new EventHandler<Event>() {
			@Override
			public void handle(Event event) {
				// TODO Auto-generated method stub
				cartSelected = cartTable.getSelectionModel().getSelectedItem();
			}
		});
	}
	
	public void fetchTableData() {
		
		fetchFoodData();
		
		ObservableList<Food> foodData = FXCollections.observableArrayList(FoodData);
		foodTable.setItems(foodData);
		
		ObservableList<Cart> cartData = FXCollections.observableArrayList(CartData);
		cartTable.setItems(cartData);
		
	}
	
	public Scene showBuyFood() {
		
		initializeBuyFood();
		setTable();
		fetchTableData();
		
		return scene;
	}
	
	private void alertMsg (String message) {
		  Alert alert = new Alert(AlertType.ERROR);    
	      alert.setContentText(message);
	      alert.show();
	}

	@Override
	public void start(Stage stage) throws Exception {
		// TODO Auto-generated method stub
		initializeBuyFood();
		setTable();
		fetchTableData();
		
		stage.setScene(scene);
		stage.setTitle("Kemanggisan Fried Chicken");
		stage.show();
		
		primaryStage = stage;
		
	}

}

package App;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.Window;

public class Login extends Application{
	
	public Stage primaryStage;
	
	Scene scene;
	
	BorderPane borderPaneLogin = new BorderPane();
	
	GridPane gridPaneLogin = new GridPane();
	
	TextField emailLoginInput = new TextField();
	
	PasswordField passwordLoginInput = new PasswordField();
	
	Button loginButton = new Button("Login");
	
	Hyperlink registerHyperlink = new Hyperlink("Don't have account? Register here");
	
	static ArrayList<User> UserData;
	
	public static User user;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch();
	}
	
	public void fetchUserData() {
		Connect connect = Connect.getInstance();
		String query = "SELECT * FROM user";
		ResultSet rs = connect.execQuery(query);
				
		UserData = new ArrayList<>();
		
		try {
			while(rs.next()) {
				
				Integer id = rs.getInt("id");
				String username = rs.getString("username");
				String password = rs.getString("password");
				String email = rs.getString("email");
				String phone_number = rs.getString("phone_number");
				String address = rs.getString("address");
				String gender = rs.getString("gender");
				String role = rs.getString("role");
				
				User user = new User(id, username, password, email, phone_number, address, gender, role);
				UserData.add(user);
				
			}
		}catch(SQLException e) {
			
			e.printStackTrace();
			
		}
	}

	public void initializeLogin() {
		
		//arraylist to fetch user data
		UserData = new ArrayList<>();
		primaryStage = new Stage();
		
		//layout
		scene = new Scene(borderPaneLogin, 600, 400);
		borderPaneLogin.setBackground(new Background(new BackgroundFill(Color.KHAKI, CornerRadii.EMPTY, Insets.EMPTY)));
				
		borderPaneLogin.setCenter(gridPaneLogin);
		borderPaneLogin.setMargin(gridPaneLogin, new Insets(20));
				
		gridPaneLogin.setHgap(20);
		gridPaneLogin.setVgap(20);
		gridPaneLogin.setAlignment(Pos.CENTER);
				
		
		//login title		
		Text loginTitle = new Text("LOGIN");
		loginTitle.setFont(new Font("Arial", 30));
		loginTitle.setStyle("-fx-font-weight: bold");
				
		borderPaneLogin.setTop(loginTitle);
		borderPaneLogin.setAlignment(loginTitle, Pos.CENTER);
		borderPaneLogin.setMargin(loginTitle, new Insets(20));
				
				
		//email login input
		Text emailLogin = new Text("Email");
		emailLogin.setFont(new Font("Arial", 18));
								
		gridPaneLogin.add(emailLogin, 0, 0);
		gridPaneLogin.add(emailLoginInput, 1, 0);
				
				
		//password login input
		Text passwordLogin = new Text("Password");
		passwordLogin.setFont(new Font("Arial", 18));
				
		gridPaneLogin.add(passwordLogin, 0, 1);
		gridPaneLogin.add(passwordLoginInput, 1, 1);		
						
				
		//login button
		loginButton.setStyle("-fx-background-color: CRIMSON; -fx-text-fill: WHITE ");
				
		gridPaneLogin.add(loginButton, 1, 2);
		
		loginButton.setOnMouseClicked(e -> {
			
			String validateEmail = emailLoginInput.getText();
			String validatePassword = passwordLoginInput.getText();
			
			String validatorFlag = "";
			
			int indexList = 0;
			for(int i = 0; i < UserData.size(); i++) {
				if(validateEmail.equals(UserData.get(i).getEmail()) && validatePassword.equals(UserData.get(i).getPassword())) {
					
					validatorFlag = "authorized";
					indexList = i;
					
				}
			}
				if(validatorFlag.equals("authorized")) {
					
					if(UserData.get(indexList).getRole().equalsIgnoreCase("user")) {
						
						user = UserData.get(indexList);
						new MainFormUser().openMainForm(new Stage());
						primaryStage.close();
						
					}else if(UserData.get(indexList).getRole().equalsIgnoreCase("administrator")) {
						
						user = UserData.get(indexList);
						new MainFormAdmin().openAdminForm(new Stage());
						primaryStage.close();
						
					}
					
				}else {
					
					showAlert(Alert.AlertType.ERROR, gridPaneLogin.getScene().getWindow(), "Error", "Invalid email/password!");
		            return;
					
				}
		
		});

				
		//register hyperlink
		borderPaneLogin.setBottom(registerHyperlink);
		borderPaneLogin.setAlignment(registerHyperlink, Pos.CENTER);
		borderPaneLogin.setMargin(registerHyperlink, new Insets(20));
		
		registerHyperlink.setOnAction( e -> {
			new Register().openRegister(new Stage());
			primaryStage.close();
		});
		
	}
	
	public void openLogin(Stage stage) {
			stage.setScene(showLogin());
			stage.show();
			this.primaryStage = stage;
	}

	public Scene showLogin() {
		
		initializeLogin();
		fetchUserData();
		
		return scene;
	}
	
	static public void showAlert(Alert.AlertType alertType, Window winMessage, String title, String message) {
		
        Alert alert = new Alert(alertType);
        
        alert.setTitle(title);
        
        alert.setHeaderText(null);
        
        alert.setContentText(message);
        
        alert.initOwner(winMessage);
        
        alert.show();
    }
	
	@Override
	public void start(Stage stage) throws Exception {
		// TODO Auto-generated method stub
		
		initializeLogin();
		fetchUserData();
		
		stage.setTitle("Kemanggisan Fried Chicken");
		stage.setScene(scene);
		stage.show();
		
		primaryStage = stage;
	
	}

}

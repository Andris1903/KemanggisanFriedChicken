package App;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class MainFormUser extends Application{
	
	private Stage primaryStage;

	public void setPrimaryStage(Stage primaryStage) {
		this.primaryStage = primaryStage;
	}

	Scene scene;
	
	BorderPane borderPaneFormUser = new BorderPane();
	
	MenuBar menuBarUser = new MenuBar();
	
	Menu menuUser1 = new Menu("Menu");
	Menu menuUser2 = new Menu("Account");
			
	MenuItem menuItemUser1 = new MenuItem("Buy Food");
//	MenuItem menuItemUser2 = new MenuItem("Manage Food");
	MenuItem menuItemUser3 = new MenuItem("Transactions");
	MenuItem menuItemUser4 = new MenuItem("Log out");
	
	public  void switchScenes(Scene scene) {
		primaryStage.setScene(scene);
	}
	public void openMainForm(Stage stage) {
		stage.setScene(showMainForm());
		stage.show();
		this.primaryStage = stage;
	}
	public void initializeMenuUser() {
		
		//layout
		scene = new Scene(borderPaneFormUser, 850, 600 );
		borderPaneFormUser.setBackground(new Background(new BackgroundFill(Color.SALMON, CornerRadii.EMPTY, Insets.EMPTY)));
		
		menuItemUser1.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				new BuyFood().openBuyFood(new Stage());
				primaryStage.close();
			}
		});
//		menuItemUser2.setOnAction(new EventHandler<ActionEvent>() {
				
//				@Override
//				public void handle(ActionEvent event) {
//					// TODO Auto-generated method stub
//					new ManageFood().openManageFood(new Stage());
//					primaryStage.close();
//					
//				}
//			});
		menuItemUser3.setOnAction(new EventHandler<ActionEvent>() {
		
		@Override
		public void handle(ActionEvent event) {
			// TODO Auto-generated method stub
			new Transaction().openTransaction(new Stage());;
			primaryStage.close();
		}
	});


		//image
		ImageView imageView = new ImageView();
		Image kfc = new Image("file:src/kfc.png", 400, 400, false, false);
		imageView.setImage(kfc);
		borderPaneFormUser.setCenter(imageView);
		

		//menu bar
		menuBarUser.getMenus().addAll(menuUser1, menuUser2);
		
		menuUser1.getItems().addAll(menuItemUser1, menuItemUser3);
		
		menuItemUser1.setOnAction(e -> {
			
			BuyFood callBuyFood = new BuyFood();
			switchScenes(callBuyFood.showBuyFood());
			
		});
		
//		menuItemUser2.setOnAction(e -> {
//			
//			ManageFood callManageFood = new ManageFood();
//			switchScenes(callManageFood.showManageFood());
//			
//		});
		
		menuItemUser3.setOnAction(e -> {
			
			Transaction callTransaction = new Transaction();
			switchScenes(callTransaction.showTransaction());
			
		});
		
		menuUser2.getItems().addAll(menuItemUser4);
		
		menuItemUser4.setOnAction(e -> {
			
			Login callLogin = new Login();
			switchScenes(callLogin.showLogin());
			
		});
		
		borderPaneFormUser.setTop(menuBarUser);
		
	}
	
	public Scene showMainForm() {
		initializeMenuUser();

		return scene;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	@Override
	public void start(Stage stage) throws Exception {
		// TODO Auto-generated method stub
		initializeMenuUser();
		
		stage.setScene(scene);
		stage.show();
		stage.setTitle("Kemanggisan Fried Chicken");
		
		primaryStage = stage;
	}

}

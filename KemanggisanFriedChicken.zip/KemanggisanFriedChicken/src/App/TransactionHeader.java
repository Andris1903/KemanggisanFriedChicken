package App;

import java.util.Date;

public class TransactionHeader {
	private int id;
	private int userID;
	private String userName;
	private String userRole;
	private String date;
	
	public TransactionHeader(int id, int userID, String userName, String userRole, String date) {
		super();
		this.id = id;
		this.userID = userID;
		this.userName = userName;
		this.userRole = userRole;
		this.date = date;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}
	
}

package App;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class MainFormAdmin extends Application{
	
	private static Stage primaryStage;

	Scene scene;
	
	BorderPane borderPaneFormAdmin = new BorderPane();
	
	public static void setPrimaryStage(Stage primaryStage) {
		MainFormAdmin.primaryStage = primaryStage;
	}

	MenuBar menuBarAdmin = new MenuBar();
	
	Menu menuAdmin1 = new Menu("Menu");
	Menu menuAdmin2 = new Menu("Account");
			
	MenuItem menuItemAdmin1 = new MenuItem("Manage Food");
	MenuItem menuItemAdmin2 = new MenuItem("Transactions");
	MenuItem menuItemAdmin3 = new MenuItem("Log out");
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}



	public void initializeMenuAdmin() {
		
				//layout
				scene = new Scene(borderPaneFormAdmin, 850, 600 );
				borderPaneFormAdmin.setBackground(new Background(new BackgroundFill(Color.SALMON, CornerRadii.EMPTY, Insets.EMPTY)));


				//image
				ImageView imageView = new ImageView();
				Image kfc = new Image("file:src/kfc.png", 400, 400, false, false);
				imageView.setImage(kfc);
				borderPaneFormAdmin.setCenter(imageView);
				

				//menu bar
				menuBarAdmin.getMenus().addAll(menuAdmin1, menuAdmin2);
				
				menuAdmin1.getItems().addAll(menuItemAdmin1, menuItemAdmin2);
				
				menuItemAdmin1.setOnAction(e -> {
					
					new ManageFood().openManageFood(new Stage());
					primaryStage.close();
				});
				
				menuItemAdmin2.setOnAction(e -> {
					
					new Transaction().openTransaction(new Stage());
					primaryStage.close();
				});
				
				menuAdmin2.getItems().addAll(menuItemAdmin3);
				
				menuItemAdmin3.setOnAction(e -> {
					
					Login callLogin = new Login();
					switchScenes(callLogin.showLogin());
					
				});
				
				borderPaneFormAdmin.setTop(menuBarAdmin);
		
	}
	
	public void openAdminForm(Stage stage) {
		stage.setScene(showMainFormAdmin());
		stage.show();
		this.primaryStage = stage;
	}



	public Scene showMainFormAdmin() {
		initializeMenuAdmin();

		return scene;
	}

	public static void switchScenes(Scene scene) {
		primaryStage.setScene(scene);
	}
	@Override
	public void start(Stage stage) throws Exception {
		// TODO Auto-generated method stub
		initializeMenuAdmin();

		stage.setScene(scene);
		stage.show();
		stage.setTitle("MacuDonals");
		
		primaryStage = stage;
	}

}

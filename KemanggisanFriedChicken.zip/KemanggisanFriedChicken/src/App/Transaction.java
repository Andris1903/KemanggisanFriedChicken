package App;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import jfxtras.labs.scene.control.window.Window;

public class Transaction extends Application{
	
	ObservableList<TransactionDetail> TransactionHeaderdetaildata;
	
	private static Stage primaryStage;
	
	ArrayList<TransactionHeader> THData;
	ArrayList<TransactionDetail> TDData;
	
	ObservableList<TransactionHeader> TransactionHeaderdata;
	
	Scene scene;
	Window window;
	
	BorderPane borderPaneTransaction = new BorderPane();
	
	GridPane gridPaneTransaction = new GridPane();
	
	FlowPane flowPaneTransaction = new FlowPane();
	
	TableView<TransactionHeader> TransactionHeaderTable;
	TableView<TransactionDetail> TransactionDetailTable;
	
	MenuBar menuBar = new MenuBar();
	Menu menu1 = new Menu("Menu");
	Menu menu2 = new Menu("Account");
	
	MenuItem menuItem1 = new MenuItem("Buy Food");
	MenuItem menuItem2 = new MenuItem("Manage Food");
	MenuItem menuItem3 = new MenuItem("Transactions");
	MenuItem menuItem4 = new MenuItem("Log out");
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	public void initializeTransaction() {
		
		THData = new ArrayList<>();
		TDData = new ArrayList<>();
		
		TransactionHeaderdetaildata = FXCollections.observableArrayList(TDData);
		
		scene = new Scene(borderPaneTransaction, 850, 580);
		window = new Window("Transactions");
		window.setMaxSize(850, 580);
		
		menuBar.getMenus().addAll(menu1, menu2);
		
		menuItem1.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				new BuyFood().openBuyFood(new Stage());
				
				primaryStage.close();
			}
		});
		
		menuItem2.setOnAction(new EventHandler<ActionEvent>() {
				
				@Override
				public void handle(ActionEvent event) {
					// TODO Auto-generated method stub
					new ManageFood().openManageFood(new Stage());
					
					primaryStage.close();
				}
			});
		
		menuItem3.setOnAction(new EventHandler<ActionEvent>() {
		
		@Override
		public void handle(ActionEvent event) {
			// TODO Auto-generated method stub
			new Transaction().openTransaction(new Stage());;
			primaryStage.close();
		}
	});
		
		if(Login.user.getRole().equalsIgnoreCase("administrator") ) {
			menu1.getItems().addAll(menuItem2, menuItem3);			
		} else {
			menu1.getItems().addAll(menuItem1, menuItem2, menuItem3);
		}
		
		menu2.getItems().addAll(menuItem4);
		
		menuItem4.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				new Login().openLogin(new Stage());;
				primaryStage.close();
			}
		});
		
		borderPaneTransaction.setTop(menuBar);
		borderPaneTransaction.setCenter(window);
		
		TransactionHeaderTable = new TableView<>();
		TransactionHeaderTable.setMaxSize(880, 250);
		
		TransactionDetailTable = new TableView<>();
		TransactionDetailTable.setMaxSize(880, 250);
		
		flowPaneTransaction.getChildren().addAll(TransactionHeaderTable, TransactionDetailTable);
		flowPaneTransaction.setVgap(10);
		flowPaneTransaction.setHgap(50);
		
		window.getContentPane().getChildren().add(flowPaneTransaction);
	}
	
	public void setTable() {
		
		//transaction header table
		TableColumn<TransactionHeader, Integer> idCol = new TableColumn<>("ID");
		idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
		idCol.setMinWidth(borderPaneTransaction.getWidth() / 5);
		
		TableColumn<TransactionHeader, Integer> idUserCol = new TableColumn<>("User ID");
		idUserCol.setCellValueFactory(new PropertyValueFactory<>("userID"));
		idUserCol.setMinWidth(borderPaneTransaction.getWidth() / 5);
		
		TableColumn<TransactionHeader, String> userNameCol = new TableColumn<>("User name");
		userNameCol.setCellValueFactory(new PropertyValueFactory<>("userName"));
		userNameCol.setMinWidth(borderPaneTransaction.getWidth() / 5);
		
		TableColumn<TransactionHeader, String> userRoleCol = new TableColumn<>("User role");
		userRoleCol.setCellValueFactory(new PropertyValueFactory<>("userRole"));
		userRoleCol.setMinWidth(borderPaneTransaction.getWidth() / 5);
		
		TableColumn<TransactionHeader, String> dateCol = new TableColumn<>("Date");
		dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));
		dateCol.setMinWidth(borderPaneTransaction.getWidth() / 5);
	
		TransactionHeaderTable.getColumns().addAll(idCol, idUserCol, userNameCol, userRoleCol, dateCol);
	
		
		//transaction detail table
		TableColumn<TransactionDetail, Integer> idColumn = new TableColumn<>("ID");
		idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
		idColumn.setMinWidth(borderPaneTransaction.getWidth() / 6);
		
		TableColumn<TransactionDetail, String> foodNameCol = new TableColumn<>("Food Name");
		foodNameCol.setCellValueFactory(new PropertyValueFactory<>("foodName"));
		foodNameCol.setMinWidth(borderPaneTransaction.getWidth() / 6);
		
		TableColumn<TransactionDetail, String> foodTypeCol = new TableColumn<>("Food Type");
		foodTypeCol.setCellValueFactory(new PropertyValueFactory<>("foodType"));
		foodTypeCol.setMinWidth(borderPaneTransaction.getWidth() / 6);
		
		TableColumn<TransactionDetail, Integer> foodPriceCol = new TableColumn<>("Food Price");
		foodPriceCol.setCellValueFactory(new PropertyValueFactory<>("foodPrice"));
		foodPriceCol.setMinWidth(borderPaneTransaction.getWidth() / 6);
		
		TableColumn<TransactionDetail, Integer> quantity = new TableColumn<>("Quantity");
		quantity.setCellValueFactory(new PropertyValueFactory<>("quantity"));
		quantity.setMinWidth(borderPaneTransaction.getWidth() / 6);
		
		TableColumn<TransactionDetail, Integer> totalPriceCol = new TableColumn<>("Total Price");
		totalPriceCol.setCellValueFactory(new PropertyValueFactory<>("totalPrice"));
		totalPriceCol.setMinWidth(borderPaneTransaction.getWidth() / 6);
	
		TransactionDetailTable.getColumns().addAll(idColumn, foodNameCol, foodTypeCol, foodPriceCol, quantity,
				totalPriceCol);
		
	}

	public void setTableData() {
		
		TransactionHeaderdata = getTransactionHeaderData();
		TransactionHeaderTable.getItems().addAll(TransactionHeaderdata);
		TransactionHeaderTable.setOnMouseClicked(new EventHandler<Event>() {
		
			@Override
			public void handle(Event event) {
				TransactionHeader th = TransactionHeaderTable.getSelectionModel().getSelectedItem();
				ResultSet rs =  Connect.getInstance().execQuery("SELECT * FROM `transaction_detail` INNER JOIN food "
						+ "ON transaction_detail.food_id = food.id WHERE transaction_detail.transaction_id = " + th.getId());
				
				TransactionHeaderdetaildata.removeAll(TransactionHeaderdetaildata);
				TDData.removeAll(TDData);
				try {
					
					while(rs.next()) {
						TDData.add(new TransactionDetail(
									rs.getInt("transaction_id"),
									rs.getString("name"),
									rs.getString("type"),
									rs.getInt("price"),
									rs.getInt("quantity"),
									rs.getInt("total_price")
								));
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				TransactionHeaderdetaildata = FXCollections.observableArrayList(TDData);
				TransactionDetailTable.setItems(TransactionHeaderdetaildata);
			}
			
		});
		
		
	}

	public void openTransaction(Stage stage) {
		
		stage.setScene(showTransaction());
		stage.show();
		this.primaryStage = stage;
		
	}
	
	public Scene showTransaction() {
		initializeTransaction();
		setTable();
		setTableData();
		
		return scene;
	}

	public static ObservableList<TransactionHeader> getTransactionHeaderData(){
		ArrayList<TransactionHeader> temp= new ArrayList<>();
		try {
			
			ResultSet rs = null;
			
			if( Login.user.getRole().equalsIgnoreCase("user")) {
				
				rs = Connect.getInstance().execQuery("SELECT transaction_id, user_id, username, role, date FROM transaction_header INNER JOIN user ON transaction_header.user_id = user.id WHERE user.id = " + Login.user.getId());
			 	
				while(rs.next()) {
			 		temp.add(new TransactionHeader(
			 					rs.getInt(1),
			 					rs.getInt(2),
			 					rs.getString(3),
			 					rs.getString(4),
			 					rs.getString(5)
	 				));
			 	}
				
			}else if(Login.user.getRole().equalsIgnoreCase("administrator")) {
				
				rs = Connect.getInstance().execQuery("SELECT transaction_id, user_id, username, role, date FROM transaction_header INNER JOIN user ON transaction_header.user_id = user.id");
			 	
				while(rs.next()) {
			 		temp.add(new TransactionHeader(
			 					rs.getInt(1),
			 					rs.getInt(2),
			 					rs.getString(3),
			 					rs.getString(4),
			 					rs.getString(5)
	 				));
			 	}	
			}
		} catch (SQLException ex) {
			// TODO Auto-generated catch block
		}
		
		return FXCollections.observableArrayList(temp);
	}
	
	public static void switchScenes(Scene scene) {
		primaryStage.setScene(scene);
	}

	@Override
	public void start(Stage stage) throws Exception {
		// TODO Auto-generated method stub
		initializeTransaction();
		setTable();
		setTableData();
		
		stage.setScene(scene);
		stage.show();
		stage.setTitle("Kemanggisan Fried Chicken");
		
		primaryStage = stage;	
	}

}


package App;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Spinner;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Background;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import jfxtras.labs.scene.control.window.Window;

public class ManageFood extends Application{
	
		private static Stage primaryStage;
		
		private Food foodSelected;
		
		ArrayList<Food> FoodData;
	
		Scene scene;
		Window window;
	
		BorderPane borderPaneManageFood = new BorderPane();
		GridPane gridPaneManageFood = new GridPane();
		
		MenuBar menuBar = new MenuBar();
		Menu menu1 = new Menu("Menu");
		Menu menu2 = new Menu("Account");
		
		MenuItem menuItem1 = new MenuItem("Buy Food");
		MenuItem menuItem2 = new MenuItem("Manage Food");
		MenuItem menuItem3 = new MenuItem("Transactions");
	
		Text id = new Text("ID");
		Text name = new Text("Name");
		Text type = new Text ("Type");
		Text stock = new Text ("Stock");
		Text price = new Text ("Price");
		
		TextField foodManageInput = new TextField();
		TextField priceManageInput = new TextField();
	
		Spinner<Integer> stockSpinner =  new Spinner<>(1, 100, 0, 1);;
		
		String typeItem[] = {"Appetizer", "Main Dish", "Side Dish", "Dessert", "Soft Drink", "Hot Drink"};
		ComboBox<String> typeList = new ComboBox<String>(FXCollections.observableArrayList(typeItem));
		
		Button insertButton = new Button("Insert");
		Button updateButton = new Button("Update");
		Button deleteButton = new Button("Delete");
		
		TableView<Food> foodTable = new TableView<>();
		
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			launch(args);
		}

		public void initializeManageFood() {
			
		//arraylist to fetch food data
		FoodData = new ArrayList<>();
		
		
		//layout
		scene = new Scene(borderPaneManageFood, 850, 600);
		
		FlowPane flowPaneManageFood = new FlowPane();
		
		foodTable.setMaxSize(850, 200);
		
		flowPaneManageFood.getChildren().addAll(foodTable, gridPaneManageFood);
		flowPaneManageFood.setVgap(10);
		flowPaneManageFood.setAlignment(Pos.CENTER);
		
		gridPaneManageFood.setHgap(20);
		gridPaneManageFood.setVgap(20);
		gridPaneManageFood.setPadding(new Insets(20));
		
		
		//menu bar
		menuBar.getMenus().addAll(menu1, menu2);
		
		menuItem1.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				new BuyFood().openBuyFood(new Stage());
				primaryStage.close();
			}
		});
		
		menuItem2.setOnAction(new EventHandler<ActionEvent>() {
				
				@Override
				public void handle(ActionEvent event) {
					// TODO Auto-generated method stub
					new ManageFood().openManageFood(new Stage());
					primaryStage.close();
				}
			});
		
		menuItem3.setOnAction(new EventHandler<ActionEvent>() {
		
		@Override
		public void handle(ActionEvent event) {
			// TODO Auto-generated method stub
			new Transaction().openTransaction(new Stage());;
			primaryStage.close();
		}
	});
		
	if(Login.user.getRole().equalsIgnoreCase("administrator") ) {
		
		menu1.getItems().addAll(menuItem2, menuItem3);		
		
	} else {
		
	menu1.getItems().addAll(menuItem1, menuItem2, menuItem3);
		
	}
		
		MenuItem menuItem4 = new MenuItem("Log out");
		
		menu2.getItems().addAll(menuItem4);
		
		borderPaneManageFood.setTop(menuBar);
		
		
		//window
		window = new Window("Manage Food");
		borderPaneManageFood.setCenter(window);
		window.setMaxSize(830, 600);
		
		window.getContentPane().getChildren().add(flowPaneManageFood);
		
		
		//insert button
		insertButton.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				if(foodManageInput.getText().isEmpty() || typeList.getValue().isEmpty() || priceManageInput.getText().isEmpty()) {
					alertMsg("Field must be filled");
					return;
					
				}else if (stockSpinner.getValue() <= 0) {
					alertMsg("Stock cannot be 0 or less");
					return;
					
				} else if (foodManageInput.getText().length() < 5 || foodManageInput.getText().length() > 30) {
					alertMsg("Food Name length more than 5-30");
					return;
					
				}  else if (!priceManageInput.getText().matches("[0-9]+")) {
					alertMsg("Input is not numeric");
					return;
					
				} else if (Integer.valueOf(priceManageInput.getText()) <= 0) {
					alertMsg("Price cannot be 0 or less");
					return;
				} 
				
				Connect.getInstance().preparedStatement("INSERT INTO food (name, type, price, stock) VALUES('"+foodManageInput.getText()+"','"+typeList.getValue()+"','" + priceManageInput.getText() + "','"+ stockSpinner.getValue() + "')");
				setFoodTableData();
			}
		});
		
		
		//update button
		updateButton.setOnAction(new EventHandler<ActionEvent>() {
		
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				if (foodSelected == null) {
					
					alertMsg("Please select food");
					return;
					
				} else if(foodManageInput.getText().length() == 0 || typeList.getValue().length() == 0 || priceManageInput.getText().length() == 0) {
					
					alertMsg("Field must not be empty");
					return;
					
				} else if (foodManageInput.getText().length() < 5 || foodManageInput.getText().length() > 30) {
					
					alertMsg("Food Name length more than or less than 5 - 30");
					return;
					
				} else if (stockSpinner.getValue() <= 0) {
					
					alertMsg("Stock cannot be 0 or minus");
					return;
					
				} else if (Integer.valueOf(priceManageInput.getText()) <= 0) {
					
					alertMsg("Price cannot be 0 or below 0");
					return;
					
				} else if (!priceManageInput.getText().matches("[0-9]+")) {
					
					alertMsg("Input must be numeric");
					return;
					
				} 
				
				Connect.getInstance().execUpdate("UPDATE food SET name = '" + foodManageInput.getText()+"', type = '"+typeList.getValue()+"', price = '"+priceManageInput.getText()+"', stock = '"+stockSpinner.getValue()+"' WHERE id = " + foodSelected.getId());
				setFoodTableData();
				infMsg("Food updated successfully");
			}
		});
		
		
		//delete button
		deleteButton.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent event) {
				
				// TODO Auto-generated method stub
				Connect.getInstance().preparedStatement("DELETE FROM food WHERE id = " + foodSelected.getId());
				setFoodTableData();
				infMsg("Food deleted successfully");
			}
		});
		
		
		//id
		gridPaneManageFood.add(id, 0, 0);
		
		
		//name
		gridPaneManageFood.add(name, 0, 1);
		gridPaneManageFood.add(foodManageInput, 1, 1);
		
		
		//type
		gridPaneManageFood.add(type, 0, 2);
		gridPaneManageFood.add(typeList, 1, 2);
		typeList.setPrefWidth(225);
		
		
		//price
		gridPaneManageFood.add(price, 0, 3);
		gridPaneManageFood.add(priceManageInput, 1, 3);
		
		
		//stock
		gridPaneManageFood.add(stock, 0, 4);
		gridPaneManageFood.add(stockSpinner, 1, 4);
		stockSpinner.setPrefWidth(225);
		
		
		//food table
		foodSelected = null;
		
		foodTable.setOnMouseClicked(new EventHandler<Event>() {

			@Override
			public void handle(Event event) {
				// TODO Auto-generated method stub
				gridPaneManageFood.getChildren().removeIf( node -> GridPane.getColumnIndex(node) == 1 && GridPane.getRowIndex(node) == 0);
				foodSelected = foodTable.getSelectionModel().getSelectedItem();
				gridPaneManageFood.add(new Text(String.valueOf(foodSelected.getId())), 1, 0);
			}
		
		});

	}
	
		public void openManageFood(Stage stage) {
			
			stage.setScene(showManageFood());
			stage.show();
			this.primaryStage = stage;
			
	}
		
	public Scene showManageFood() {
			
			initializeManageFood();
			adminInputLayout();
			setFoodTable();
			setFoodTableData();
			
			return scene;
		}

	public void adminInputLayout() {
		
		if(Login.user.getRole().equalsIgnoreCase("administrator")) {
			
			gridPaneManageFood.add(insertButton, 2, 1);			
			
			gridPaneManageFood.add(updateButton, 2, 2);
			
			gridPaneManageFood.add(deleteButton, 2, 4);
			
		}
		
	}
	
	public void setFoodTable() {
		TableColumn<Food, Integer> idCol = new TableColumn<>("ID");
		idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
		idCol.setMinWidth(80);
		
		TableColumn<Food, String> nameCol = new TableColumn<>("Name");
		nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
		nameCol.setMinWidth(borderPaneManageFood.getWidth()/4.2);
		
		TableColumn<Food, String> typeCol = new TableColumn<>("Type");
		typeCol.setCellValueFactory(new PropertyValueFactory<>("type"));
		typeCol.setMinWidth(borderPaneManageFood.getWidth()/4.2);
		
		TableColumn<Food, Integer> priceCol = new TableColumn<>("Price");
		priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
		priceCol.setMinWidth(borderPaneManageFood.getWidth()/4.2);
		
		TableColumn<Food, Integer> stockCol = new TableColumn<>("Stock");
		stockCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
		stockCol.setMinWidth(borderPaneManageFood.getWidth()/4.2);
				
		foodTable.getColumns().addAll(idCol, nameCol, typeCol, priceCol, stockCol);
	}
	
	public void setFoodTableData() {
		foodTable.getItems().clear();
		getFoodData();
		ObservableList<Food> marketdata = FXCollections.observableArrayList(FoodData);
		foodTable.setItems(marketdata);
		
	}
	
	public void getFoodData() {
		FoodData.clear();
		Connect connect = Connect.getInstance();
		String query = "SELECT * FROM food";
		ResultSet rs = connect.execQuery(query);
				
		try {
			while(rs.next()) {
				Integer id = rs.getInt("id");
				String name = rs.getString("name");
				String type = rs.getString("type");
				Integer price = rs.getInt("price");
				Integer stock = rs.getInt("stock");
				
				Food food = new Food(id, name, type, price, stock);
				FoodData.add(food);
				
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void switchScenes(Scene scene) {
		primaryStage.setScene(scene);
	}

	private void alertMsg (String pesan) {
		
		  Alert alert = new Alert(AlertType.ERROR);    
	      alert.setContentText(pesan);
	      alert.show();
	      
	}
	
	private void infMsg (String pesan) {
		
		  Alert alert = new Alert(AlertType.INFORMATION);    
	      alert.setContentText(pesan);
	      alert.show();
	      
	}

	@Override
	public void start(Stage stage) throws Exception {
		// TODO Auto-generated method stub
		initializeManageFood();
		adminInputLayout();
		setFoodTable();
		setFoodTableData();
		
		stage.setScene(scene);
		stage.show();
		stage.setTitle("Kemanggisan Fried Chicken");
		System.out.println(foodTable);
		primaryStage = stage;
	}

}

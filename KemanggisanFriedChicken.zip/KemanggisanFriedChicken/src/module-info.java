module BADProject {
	opens App;
	requires javafx.graphics;
	requires javafx.controls;
	requires java.desktop;
	requires java.sql;
	requires javafx.base;
	requires jfxtras.labs;
}